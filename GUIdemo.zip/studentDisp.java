package GUIdemo;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.*;

public class studentDisp extends JFrame{
	JLabel num,name,tel,sex,age,banji,dorm,dept;
	JPanel jp1,jp2;
	JButton jb1,jb2;
	private DBconnect DB = new DBconnect();
	public studentDisp(int num,String name,String tel,String sex,String age
			,String banji,String dorm,String dept) {
		super();
		this.num=new JLabel("ѧ�� :"+num,JLabel.CENTER);
		this.name=new JLabel("���� :"+name,JLabel.CENTER);
		this.tel=new JLabel("�绰 :"+tel,JLabel.CENTER);
		this.sex=new JLabel("�Ա� :"+sex,JLabel.CENTER);
		this.age=new JLabel("���� :"+age,JLabel.CENTER);
		this.banji=new JLabel("�༶ :"+banji,JLabel.CENTER);
    	this.dorm=new JLabel("���� :"+dorm,JLabel.CENTER);
		this.dept=new JLabel("ϵ�� :"+dept,JLabel.CENTER);
		
		Font font = new Font("��������", Font.BOLD|Font.PLAIN, 14);
		this.num.setFont(font);
		this.name.setFont(font);
		this.tel.setFont(font);
		this.sex.setFont(font);
		this.age.setFont(font);	
		this.banji.setFont(font);
		this.dorm.setFont(font);
		this.dept.setFont(font);
		jb1=new JButton("�ϱ�");
		jb2=new JButton("����������");
		
		jp1=new JPanel();
		jp2=new JPanel();
		
		jp1.setLayout(new GridLayout(2,3));
		jp1.add(this.num);
		jp1.add(this.name);
		jp1.add(this.sex);
		jp1.add(this.age);
		jp1.add(this.dorm);
		jp1.add(this.dept);
		jp1.add(this.tel);
		jp1.add(this.banji);
		jp2.add(jb1);
		jp2.add(jb2);
		setLayout(new GridLayout(2,1));
		add(jp1);
		add(jp2);
		
		setTitle("ѧ������");
		setSize(600,300);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);	
		
		jb1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String sql="UPDATE report_info\n" +
							"SET Report_TF = '��'\n" +
							"WHERE Stu_num="+num;
					Statement statement=DB.dbConn.createStatement();
					statement.executeUpdate(sql);
					DB.dbConn.close();
				}catch(Exception ei) {
					ei.printStackTrace();
				}
				JOptionPane.showMessageDialog(null, "�����ϱ��ɹ���");
				}});
		jb2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new mainDisp();
				}});
	}
	public static void main(String[] args) {
		new studentDisp(20111111,"����","1111111111","��","19","�����18-5��","1320","�����");
	}
}
