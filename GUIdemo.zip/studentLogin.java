package GUIdemo;

import java.awt.*;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class studentLogin extends JFrame{
	JTextArea t;
	JPasswordField ps;
	JPanel jp1,jp2,jp3;
	JLabel jl1,jl2;
	JButton jb;
	static String psword="123";
	
	public studentLogin() {
		super();
		DBconnect j = new DBconnect();
		jb=new JButton("��¼");
		jl1=new JLabel("  ѧ   ��:");
		jl2=new JLabel("  ��   ��:");
		jp1=new JPanel();
		jp2=new JPanel();
		jp3=new JPanel();
		t=new JTextArea(1, 10);
		ps=new JPasswordField(10);
		
		Font font = new Font("��������", Font.BOLD|Font.PLAIN, 14);
		jl1.setFont(font);
		jl2.setFont(font);

		jp1.setLayout(new GridLayout(3,2));
		jp1.add(jl1);
		jp1.add(t);
		jp1.add(jl2);
		jp1.add(ps);
		jp2.add(jb);
		setLayout(new GridLayout(3,1));
		add(jp1);
		add(jp2);
		
		setTitle("ѧ����¼");
		setSize(300,300);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String acct=t.getText();
				int stu_num=Integer.parseInt(acct);
				char[] psw=ps.getPassword();
				String pass=new String(psw);
				String[] str=new String[10];
				int i=0;
				if(pass.equals(psword)) {
					try {
						String sql="SELECT * FROM stu_info,stay_info,dept_info\n" +
								"WHERE stu_info.Dept_num=dept_info.Dept_num\n" +
								"AND stu_info.Stu_num=stay_info.Stu_num\n" +
								"AND stu_info.Stu_num="+stu_num;
						Statement statement=j.dbConn.createStatement();
						ResultSet res=statement.executeQuery(sql);
						while(res.next()){
							str[0]=res.getString(2);
							str[1]=res.getString(7);
							str[2]=res.getString(3);
							str[3]=res.getString(4);
							str[4]=res.getString(6);
							str[5]=res.getString(8);
							str[6]=res.getString(12);
						}
						res.close();
					}catch(Exception ei) {
						ei.printStackTrace();
					}
					setVisible(false);
					new studentDisp(stu_num,str[0],str[1],str[2],str[3],str[4],str[5],str[6]);
					}
				else {
					JOptionPane.showMessageDialog(null, "���벻��ȷ�����������룡");
					t.setText(null);
					ps.setText(null);
				}
				}		
				}
				);
	}
	public static void main(String[] args) {
		new studentLogin();
	}
}
