package GUIdemo;

import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class workeDisp extends JFrame{
	JLabel num,name,tel,sex,funcation,dormdun,workfloor;
	//���������¼����������¼
	JPanel jp1,jp2,jp3;
	
	public workeDisp(String num,String name,String tel,String sex,String funcation
			,String dormdun,String workfloor) {
		super();
		this.num=new JLabel("ְ����"+num);
		this.name=new JLabel("����"+name);
		this.tel=new JLabel("�绰"+tel);
		this.sex=new JLabel("�Ա�"+sex);
		this.funcation=new JLabel("ְ��"+funcation);
		this.dormdun=new JLabel("����¥��"+dormdun);
		this.workfloor=new JLabel("�����ص�"+workfloor);
		jp1=new JPanel();
		jp2=new JPanel();
		jp3=new JPanel();
		
		jp1.add(this.num);
		jp1.add(this.name);
		jp1.add(this.sex);
		jp2.add(this.funcation);
		jp2.add(this.dormdun);
		jp2.add(this.workfloor);
		jp3.add(this.tel);
		setLayout(new GridLayout(3,1));
		add(jp1);
		add(jp2);
		add(jp3);
		
		setTitle("������Ա����");
		setSize(800,500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);	
	}
	public static void main(String[] args) {
		new workeDisp("2","2","2","2","2","2","2");
	}

}
