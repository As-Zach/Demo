package GUIdemo;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class workerLogin extends JFrame{
	JTextArea t;
	JPasswordField ps;
	JPanel jp1,jp2,jp3;
	JLabel jl1,jl2;
	JButton jb;
	static String account="root";
	static String psword="123";
	
	public workerLogin() {
		super();
		jb=new JButton("��¼");
		jl1=new JLabel("������:");
		jl2=new JLabel("����:");
		jp1=new JPanel();
		jp2=new JPanel();
		jp3=new JPanel();
		t=new JTextArea(1, 10);
		ps=new JPasswordField(10);
		
		setLayout(new GridLayout(3,1));
		jp1.add(jl1);
		jp1.add(t);
		jp2.add(jl2);
		jp2.add(ps);
		jp3.add(jb);
		add(jp1);
		add(jp2);
		add(jp3);
		
		setTitle("������Ա��¼");
		setSize(800,500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String acct=t.getText();
				if(acct.equals(account)) {
					char[] psw=ps.getPassword();
					String pass=new String(psw);
					if(pass.equals(psword)) {
						setVisible(false);
						new workeDisp(null, null, null, null, null, null, null);
					}
					else {
						JOptionPane.showMessageDialog(null, "���벻��ȷ�����������룡");
						ps.setText(null);
					}
					}
				else {
					JOptionPane.showMessageDialog(null, "���Ų����ڣ����������룡");
					t.setText(null);
					ps.setText(null);
				}
				}		
				}
				);	
	}
	public static void main(String[] args) {
		new workerLogin();
	}


}
