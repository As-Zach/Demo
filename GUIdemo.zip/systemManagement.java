package GUIdemo;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class systemManagement {
	public static void main(String[] args) {
		//new UserTable();
		//new UserDelete();
		//new UserCheckin();
	}
}

class UserCheckin extends JDialog{
	private JLabel jl1,jl2;
	private JTextField jt1,jt2;
	private JButton jb1;
	private JPanel jp1,jp2;
	private DBconnect DB = new DBconnect();
	
	UserCheckin(){
		super();
		jp1=new JPanel();
		jp2=new JPanel();
		jt1=new JTextField(6);
		jt2=new JTextField(6);
		jl1=new JLabel("��    ����");
		jl2=new JLabel("��    �룺");
		jl1.setFont(new Font("��������", Font.BOLD|Font.PLAIN, 14));
		jl2.setFont(new Font("��������", Font.BOLD|Font.PLAIN, 14));
		
		jb1=new JButton("��    ��");
		jp1=new JPanel();
		jp2=new JPanel();
		
		jp1.setLayout(new GridLayout(2,2));
		jp1.add(jl1);
		jp1.add(jt1);
		jp1.add(jl2);
		jp1.add(jt2);
		jp2.add(jb1);
		this.setLayout(new GridLayout(3,1));
		this.add(jp1);
		this.add(jp2);
		
		setTitle("�����û� ");
		setSize(300,200);
		setVisible(true);
		setLocationRelativeTo(null);
		
		jb1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String acct=jt1.getText();
				String psw=jt2.getText();
				int Flag=0;
				try {
					String sql="Select * from users_info where Users_ID='"+acct+"'";
					Statement statement1=DB.dbConn.createStatement();
					ResultSet res=statement1.executeQuery(sql);
					if(res.next()) Flag=1;
					res.close();
				}catch(Exception ei) {
					ei.printStackTrace();
				}
				
				if(Flag==1) {
					JOptionPane.showMessageDialog(null, "�˻��Ѵ��ڣ����������룡");
					jt1.setText("");
					jt2.setText("");
				}
				else {
					try {
						String sql1="Select MAX(Users_num) from users_info ";
						Statement statement=DB.dbConn.createStatement();
						ResultSet res=statement.executeQuery(sql1);
						res.next();
						int i=res.getInt(1)+1;

						String sql="insert into Users_info values ("+i+",'"+acct+"','"+psw+"')";
						statement.executeUpdate(sql);
						
					}catch(Exception ei) {
						ei.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "�����ɹ���");
					jt1.setText("");
					jt2.setText("");
				}}		});
	}
}
class UserDelete extends JDialog{
	private JTextField jt1;
	private JLabel jl1;
	private JButton jb1;
	private JPanel jp1,jp2;
	private DBconnect DB = new DBconnect();
	
	public UserDelete() {
		super();
		jt1=new JTextField(10);
		jl1=new JLabel("��    ����");
		jl1.setFont(new Font("��������", Font.BOLD|Font.PLAIN, 14));
		jb1=new JButton("ɾ     ��");
		jp1=new JPanel();
		jp2=new JPanel();
		
		
		jp1.add(jl1);
		jp1.add(jt1);
		jp2.add(jb1);
		this.setLayout(new GridLayout(2,1));
		this.add(jp1);
		this.add(jp2);
		
		setTitle("�û�ɾ��");
		setSize(400,300);
		setVisible(true);
		setLocationRelativeTo(null);
		
		jb1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String acct=jt1.getText();
				int Flag=0;
				try {
					String sql="Select * from users_info where Users_ID='"+acct+"'";
					Statement statement1=DB.dbConn.createStatement();
					ResultSet res=statement1.executeQuery(sql);
				    if(res.next()) Flag=1;
					res.close();
				}catch(Exception ei) {
					ei.printStackTrace();
				}
				
				if(Flag==0) {
					JOptionPane.showMessageDialog(null, "�˻������ڣ����������룡");
					jt1.setText("");
				}
				else {
					try {
						String sql="delete from users_info where Users_ID='"+acct+"'";
						Statement statement=DB.dbConn.createStatement();
						statement.executeUpdate(sql);
						
					}catch(Exception ei) {
						ei.printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "ɾ���ɹ���");
					jt1.setText("");
				}}});
	}
}



class UserTable extends JFrame{
	private JLabel jl;
	private JTable table;
	private DefaultTableModel model;
	private DBconnect DB = new DBconnect();

	public UserTable() {
		super();
		setLayout(new BorderLayout());
		model=new DefaultTableModel();
		table=new JTable();
		table.setModel(model);
		JScrollPane jsp=new JScrollPane(table);
		jl=new JLabel("��  ��  ��  Ϣ  ��");
		jl.setFont(new Font("���Ĳ���", Font.BOLD|Font.PLAIN, 20));

		this.add(jl,BorderLayout.NORTH);
		this.add(jsp,BorderLayout.CENTER);

		this.setTitle("�û���Ϣ����");
		setSize(500,500);
		model.setRowCount(0);
		model.setColumnCount(0);
		try {
			String sql="SELECT * FROM users_info";
			Statement statement=DB.dbConn.createStatement();
			ResultSet res=statement.executeQuery(sql);
			//��ȡ������������������Ϊ��������ı���
			ResultSetMetaData rsmd=res.getMetaData();
			//�������
			int count=rsmd.getColumnCount();
			////���������ӵ�����ģ����Ϊ����
			for(int i=1;i<=count;i++){
				model.addColumn(rsmd.getColumnName(i));
			}
			String[] row=new String[count];
			while(res.next()){
				for(int i=0;i<count;i++)
					row[i]=res.getString(i+1);
				//����һ��
				model.addRow(row);
			}
			res.close();
		}catch(Exception ei) {
			ei.printStackTrace();
		}
		setVisible(true);
		setLocationRelativeTo(null);
	}

}
