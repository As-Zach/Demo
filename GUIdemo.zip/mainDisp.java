package GUIdemo;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.*;

public class mainDisp extends JFrame{
	JButton jb1,jb2;
	JPanel jp1,jp2,jp3;
	JLabel jl1,jl2;
	DBconnect DB = new DBconnect();
		
	public mainDisp() {
		super();

		jb1=new JButton("�޹�");
		jb2=new JButton("ѧ��");
		jp1=new JPanel();
		jp2=new JPanel();
		jp3=new JPanel();
		jl1=new JLabel("�������ϵͳ");
		jl2=new JLabel("��ѡ���¼����");
		
		jl1.setFont(new Font("��������",Font.BOLD|Font.PLAIN,40));
		jl1.setForeground(Color.black);
		jl2.setFont(new Font("��������",Font.BOLD|Font.PLAIN,20));
		jl2.setForeground(Color.blue);
        
		jp1.add(jl1);
		jp2.add(jl2);
		jp3.add(jb1);
		jp3.add(jb2);
		setLayout(new GridLayout(3,1));
		add(jp1);
		add(jp2);
		add(jp3);
		
		setTitle("�û���¼");
		setSize(400,300);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		
		
		jb1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new dormitoryLogin();
				}});
		jb2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new studentLogin();
				}});

	}
	public static void main(String[] args) {
		new mainDisp();
	}
}
