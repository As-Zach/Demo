package GUIdemo;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

public class dormManagement {
	public static void main(String[] args) {
		//new dormSearch();
		//new dormChange();
		//new dormRepair();
		//new dormMoney();
		//new dormTable();
		//new dormInsert();
		new repairInsert();
	}
}
class dormSearch extends JDialog implements ActionListener {
	private JTextField jt;
	private JButton jb;
	private JComboBox cmb;
	private JPanel jp;
	private JTable table;
	private DefaultTableModel model;
	private DBconnect DB = new DBconnect();
	private String[] srr={"---��ѡ���ѯ��ʽ---","�������ѯ","��ѧ�Ų�ѯ"};
	public dormSearch(){
		super();
		setLayout(new BorderLayout());
		setTitle("��ס��Ϣ��ѯ");
		setSize(500,300);
		setLocationRelativeTo(null);
		jt=new JTextField(10);
		jb = new JButton("��ѯ");
		jp = new JPanel();
		model=new DefaultTableModel();
		table=new JTable();
		table.setModel(model);
		JScrollPane jsp=new JScrollPane(table);
		cmb = new JComboBox(srr);
		add(jp,BorderLayout.NORTH);
		this.add(jsp,BorderLayout.CENTER);
		jp.add(cmb);
		jp.add(jt);
		jp.add(jb);
		jb.addActionListener(this);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (cmb.getSelectedIndex()==2) {
			model.setRowCount(0);
			model.setColumnCount(0);
			try {
				String str1=jt.getText();
				String sql = "select * from stay_info where Stu_num="+str1;
				Statement statement = DB.dbConn.createStatement();
				ResultSet res=statement.executeQuery(sql);
				//��ȡ������������������Ϊ��������ı���
				ResultSetMetaData rsmd=res.getMetaData();
				//�������
				int count=rsmd.getColumnCount();
				////���������ӵ�����ģ����Ϊ����
				for(int i=1;i<=count;i++){
					model.addColumn(rsmd.getColumnName(i));
				}
				String[] row=new String[count];
				while(res.next()){
					for(int i=0;i<count;i++)
						row[i]=res.getString(i+1);
					//����һ��
					model.addRow(row);
				}
				res.close();
			} catch (Exception ei) {
				ei.printStackTrace();
			}
		}
		else if (cmb.getSelectedIndex()==1){
			model.setRowCount(0);
			model.setColumnCount(0);
			try {
				String str1=jt.getText();
				String sql="select * from stay_info where Dorm_num="+str1;
				Statement statement=DB.dbConn.createStatement();
				ResultSet res=statement.executeQuery(sql);
				//��ȡ������������������Ϊ��������ı���
				ResultSetMetaData rsmd=res.getMetaData();
				//�������
				int count=rsmd.getColumnCount();
				////���������ӵ�����ģ����Ϊ����
				for(int i=1;i<=count;i++){
					model.addColumn(rsmd.getColumnName(i));
				}
				String[] row=new String[count];
				while(res.next()){
					for(int i=0;i<count;i++)
						row[i]=res.getString(i+1);
					//����һ��
					model.addRow(row);
				}
				res.close();
			}catch(Exception ei) {
				ei.printStackTrace();
			}
		}
	}
}

class dormChange extends JDialog implements ActionListener{
	private JLabel jl;
	private JTable table;
	private JButton jb1,jb2;
	private JPanel jp;
	private DefaultTableModel model;
	private DBconnect DB = new DBconnect();

	public dormChange(){
		super();
		setLayout(new BorderLayout());
		setTitle("ѧ������");
		setSize(500,300);
		setLocationRelativeTo(null);
		jl=new JLabel("��  ��  ��  Ϣ  ��");
		jl.setFont(new Font("���Ĳ���", Font.BOLD|Font.PLAIN, 20));
		jb1 = new JButton("����");
		jb2 = new JButton("ˢ��");
		jp = new JPanel();
		model=new DefaultTableModel();
		table=new JTable();
		table.setModel(model);
		JScrollPane jsp=new JScrollPane(table);

		this.add(jp,BorderLayout.NORTH);
		this.add(jsp,BorderLayout.CENTER);
		jp.add(jl);
		jp.add(jb1);
		jp.add(jb2);
		jb1.addActionListener(this);
		jb2.addActionListener(this);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == jb2){
			model.setRowCount(0);
			model.setColumnCount(0);
			try {
				String sql="SELECT * FROM change_info";
				Statement statement=DB.dbConn.createStatement();
				ResultSet res=statement.executeQuery(sql);
				//��ȡ������������������Ϊ��������ı���
				ResultSetMetaData rsmd=res.getMetaData();
				//�������
				int count=rsmd.getColumnCount();
				////���������ӵ�����ģ����Ϊ����
				for(int i=1;i<=count;i++){
					model.addColumn(rsmd.getColumnName(i));
				}
				String[] row=new String[count];
				while(res.next()){
					for(int i=0;i<count;i++)
						row[i]=res.getString(i+1);
					//����һ��
					model.addRow(row);
				}
				res.close();
			}catch(Exception ei) {
				ei.printStackTrace();
			}
		}
		else {
			new dormInsert();
		}
	}
}

class dormInsert extends JDialog implements ActionListener{
	private JTextField jtf1,jtf2,jtf3;
	private JButton jb,jb1;
	private JLabel jl1,jl2,jl3,jl4;
	private JRadioButton jrb1,jrb2;
	private JPanel jp;
	private DBconnect DB = new DBconnect();

	public dormInsert(){
		super();
		setLayout(new GridLayout(5,2));
		setTitle("ѧ������");
		setSize(300,200);
		setLocationRelativeTo(null);
		jb = new JButton("��  ��");
		jb1 = new JButton("ȡ  ��");
		jl1 = new JLabel("ѧ  �ţ�");
		jl2 = new JLabel("��  ��  ��:");
		jl3 = new JLabel("��  ��  ԭ  ��:");
		jl4 = new JLabel("��  ��  ��  ׼:");
		jrb1=new JRadioButton("��");
		jrb2=new JRadioButton("��");
		jp = new JPanel();
		jtf1 = new JTextField(10);
		jtf2 = new JTextField(10);
		jtf3 = new JTextField(10);
		add(jl1);
		add(jtf1);
		add(jl2);
		add(jtf2);
		add(jl3);
		add(jtf3);
		add(jl4);
		add(jp);
		add(jb);
		add(jb1);
		jp.add(jrb1);
		jp.add(jrb2);
		jb.addActionListener(this);
		jb1.addActionListener(this);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == jb){
			int num = Integer.parseInt(jtf1.getText());
			int dorm = Integer.parseInt(jtf2.getText());
			String reason = jtf3.getText();
			String str5 = null;
			if (jrb1.isSelected()){
				str5="��";
			}
			else if (jrb2.isSelected()){
				str5="��";
			}
			try {
				String sql1="select MAX(Chg_num) from change_info";
				Statement statement=DB.dbConn.createStatement();
				ResultSet res = statement.executeQuery(sql1);
				res.next();
				int i = res.getInt(1)+1;
				String sql2 = "INSERT change_info VALUES("+num+","+dorm+","+i+",'"+reason+"','"+str5+"')";
				statement.executeUpdate(sql2);
				JOptionPane.showMessageDialog(null,"����ɹ���");
			}catch(Exception ei) {
				ei.printStackTrace();
			}
		}
		else {
			dispose();
		}
	}
}

class dormRepair extends JDialog implements ActionListener{
	private JLabel jl;
	private JTable table;
	private JPanel jp,jp1;
	private JButton jb1,jb2;
	private DefaultTableModel model;
	private DBconnect DB = new DBconnect();

	public dormRepair(){
		super();
		setLayout(new BorderLayout());
		setTitle("����ά�޹���");
		setSize(500,300);
		setLocationRelativeTo(null);
		jl=new JLabel("ά  ��  ��  Ϣ  ��");
		jb1 = new JButton("ˢ��");
		jb2 = new JButton("����");
		jp=new JPanel();
		jp1 = new JPanel();
		jp.setLayout(new GridLayout(1,2));
		jl.setFont(new Font("���Ĳ���", Font.BOLD|Font.PLAIN, 20));
		model=new DefaultTableModel();
		table=new JTable();
		table.setModel(model);
		JScrollPane jsp=new JScrollPane(table);

		this.add(jp,BorderLayout.NORTH);
		this.add(jsp,BorderLayout.CENTER);
		jp.add(jl);
		jp.add(jp1);
		jp1.add(jb1);
		jp1.add(jb2);
		jb1.addActionListener(this);
		jb2.addActionListener(this);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource()==jb1){
			model.setRowCount(0);
			model.setColumnCount(0);
			try {
				String sql="SELECT * FROM repair_info";
				Statement statement=DB.dbConn.createStatement();
				ResultSet res=statement.executeQuery(sql);
				//��ȡ������������������Ϊ��������ı���
				ResultSetMetaData rsmd=res.getMetaData();
				//�������
				int count=rsmd.getColumnCount();
				////���������ӵ�����ģ����Ϊ����
				for(int i=1;i<=count;i++){
					model.addColumn(rsmd.getColumnName(i));
				}
				String[] row=new String[count];
				while(res.next()){
					for(int i=0;i<count;i++)
						row[i]=res.getString(i+1);
					//����һ��
					model.addRow(row);
				}
				res.close();
			}catch(Exception ei) {
				ei.printStackTrace();
			}
		}
		else {
			new repairInsert();
		}
	}
}

class repairInsert extends JDialog implements ActionListener{
	private JTextField jtf1,jtf2,jtf3,jtf4;
	private JButton jb,jb1;
	private JLabel jl1,jl2,jl3,jl4;
	private DBconnect DB = new DBconnect();

	public repairInsert(){
		super();
		setLayout(new GridLayout(5,2));
		setTitle("ά����Ϣ����");
		setSize(300,200);
		setLocationRelativeTo(null);
		jb = new JButton("��  ��");
		jb1 = new JButton("ȡ  ��");
		jl1 = new JLabel("��  ��  �ţ�");
		jl2 = new JLabel("��  ��  ��  ��:");
		jl3 = new JLabel("��  ��  ��  ��:");
		jl4 = new JLabel("ά  ��  ԭ  ��:");
		jtf1 = new JTextField(10);
		jtf2 = new JTextField(10);
		jtf3 = new JTextField(10);
		jtf4 = new JTextField(10);
		add(jl1);
		add(jtf1);
		add(jl2);
		add(jtf2);
		add(jl3);
		add(jtf3);
		add(jl4);
		add(jtf4);
		add(jb);
		add(jb1);
		jb.addActionListener(this);
		jb1.addActionListener(this);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == jb){
			int num = Integer.parseInt(jtf1.getText());
			String ad= jtf2.getText();
			String cd = jtf3.getText();
			String reason = jtf4.getText();
			try {
				String sql1="select MAX(Repair_num) from repair_info";
				Statement statement=DB.dbConn.createStatement();
				ResultSet res = statement.executeQuery(sql1);
				res.next();
				int i = res.getInt(1)+1;
				String sql2 = "INSERT repair_info VALUES("+num+","+i+",'"+ad+"','"+cd+"','"+reason+"')";
				statement.executeUpdate(sql2);
				JOptionPane.showMessageDialog(null,"����ɹ���");
			}catch(Exception ei) {
				ei.printStackTrace();
			}
		}
		else {
			dispose();
		}
	}
}
class dormMoney extends JDialog implements ItemListener {
	private JTable table;
	private DefaultTableModel model;
	private JComboBox jc;
	private DBconnect DB = new DBconnect();

	public dormMoney() {
		super();
		String[] str= {"---��ѡ��---","ˮ�Ѳ�ѯ","��Ѳ�ѯ"};
		jc=new JComboBox<String>(str);
		model=new DefaultTableModel();
		table=new JTable();
		table.setModel(model);
		JScrollPane jsp=new JScrollPane(table);
		setLayout(new BorderLayout());
		setTitle("����ά�޹���");
		setSize(500, 300);
		setLocationRelativeTo(null);
		this.add(jc,BorderLayout.NORTH);
		this.add(jsp,BorderLayout.CENTER);
		jc.addItemListener(this);
		setVisible(true);
	}

	public void itemStateChanged(ItemEvent e) {
		model.setRowCount(0);
		model.setColumnCount(0);
		if(e.getStateChange() == ItemEvent.SELECTED) {
			//�������ݿ��������ֱ�
			String str1=null;
			if(jc.getSelectedItem().toString().equals("ˮ�Ѳ�ѯ"))
				str1="ˮ��";
			else if (jc.getSelectedItem().toString().equals("��Ѳ�ѯ"))
				str1="���";
			try {
				String sql="SELECT * FROM type_info,money_info\n" +
						"WHERE Type_name='"+str1+"'" +
						"AND money_info.Money_type=type_info.Type_num";
				Statement statement=DB.dbConn.createStatement();
				ResultSet res=statement.executeQuery(sql);
				//��ȡ������������������Ϊ��������ı���
				ResultSetMetaData rsmd=res.getMetaData();
				//�������
				int count=rsmd.getColumnCount();
				////���������ӵ�����ģ����Ϊ����
				for(int i=1;i<=count;i++){
					model.addColumn(rsmd.getColumnName(i));
				}
				String[] row=new String[count];
				while(res.next()){
					for(int i=0;i<count;i++)
						row[i]=res.getString(i+1);
					//����һ��
					model.addRow(row);
				}
				res.close();
			}catch(Exception ei) {
				ei.printStackTrace();
			}
		}
	}
}

class dormTable extends JDialog {
	private JLabel jl;
	private JTable table;
	private DefaultTableModel model;
	private DBconnect DB = new DBconnect();

	public dormTable() {
		super();
		setLayout(new BorderLayout());
		model=new DefaultTableModel();
		table=new JTable();
		table.setModel(model);
		JScrollPane jsp=new JScrollPane(table);
		jl=new JLabel("��  ��  ��  Ϣ  ��");
		jl.setFont(new Font("���Ĳ���", Font.BOLD|Font.PLAIN, 20));

		this.add(jl,BorderLayout.NORTH);
		this.add(jsp,BorderLayout.CENTER);

		this.setTitle("������Ϣ����");
		setSize(800,500);
		model.setRowCount(0);
		model.setColumnCount(0);
		try {
			String sql="SELECT stay_info.*,Dis_sleep,Dis_healthy,Discipline FROM stay_info,discipline_info\n" +
					"WHERE stay_info.Dorm_num=discipline_info.Dorm_num";
			Statement statement=DB.dbConn.createStatement();
			ResultSet res=statement.executeQuery(sql);
			//��ȡ������������������Ϊ��������ı���
			ResultSetMetaData rsmd=res.getMetaData();
			//�������
			int count=rsmd.getColumnCount();
			////���������ӵ�����ģ����Ϊ����
			for(int i=1;i<=count;i++){
				model.addColumn(rsmd.getColumnName(i));
			}
			String[] row=new String[count];
			while(res.next()){
				for(int i=0;i<count;i++)
					row[i]=res.getString(i+1);
				//����һ��
				model.addRow(row);
			}
			res.close();
		}catch(Exception ei) {
			ei.printStackTrace();
		}
		setVisible(true);
		setLocationRelativeTo(null);
	}

}