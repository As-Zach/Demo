package GUIdemo;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.*;

public class dormitoryLogin extends JFrame{
	JTextArea t;
	JPasswordField ps;
	JPanel jp1,jp2,jp3;
	JLabel jl1,jl2;
	JButton jb;
	static String account="root";
	static String psword="123";
	private DBconnect DB = new DBconnect();
	private String[][] user = new String[20][2];
	
	public dormitoryLogin() {
		super();
		jb=new JButton("��¼");
		jl1=new JLabel("  ��   ��:");
		jl2=new JLabel("  ��   ��:");
		jp1=new JPanel();
		jp2=new JPanel();
		jp3=new JPanel();
		t=new JTextArea(1, 10);
		ps=new JPasswordField(10);
		
		Font font = new Font("��������", Font.BOLD|Font.PLAIN, 14);
		jl1.setFont(font);
		jl2.setFont(font);

		jp1.setLayout(new GridLayout(3,2));
		jp1.add(jl1);
		jp1.add(t);
		jp1.add(jl2);
		jp1.add(ps);
		jp2.add(jb);
		setLayout(new GridLayout(3,1));
		add(jp1);
		add(jp2);
		
		setTitle("�޹ܵ�¼");
		setSize(300,300);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
		int i=0;
		try{
			String sql = "select * from users_info ";
			Statement statement = DB.dbConn.createStatement();
			ResultSet res = statement.executeQuery(sql);
			while (res.next()){
				user[i][0] = res.getString(2);
				user[i][1] = res.getString(3);
				i++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String acct=t.getText();
				char[] psw=ps.getPassword();
				String pass=new String(psw);
				Boolean flag1=false,flag2=false;
				for (int m = 0; m<user.length; m++){
					if (acct.equals(user[m][0]))
						flag1=true;
					if (pass.equals(user[m][1]))
						flag2=true;
				}
				if(acct.equals(account) || flag1) {
					if(pass.equals(psword) || flag2) {
						setVisible(false);
						new dormitoryDisp();
					}
					else {
						JOptionPane.showMessageDialog(null, "���벻��ȷ�����������룡");
						ps.setText(null);
					}
					}
				else {
					JOptionPane.showMessageDialog(null, "�˻������ڣ����������룡");
					t.setText(null);
					ps.setText(null);
				}
				}		
				}
				);
	}
	public static void main(String[] args) {
		new dormitoryLogin();
	}
}
