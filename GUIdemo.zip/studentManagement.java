package GUIdemo;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class studentManagement {
	public static void main(String[] args) {
		//new studentOut();
		//new studentQueryAlter();
		//new studentTable();
		//new classQuery();
		new studentReport();
	}

}
class studentOut extends JDialog{
	private JTextField jt1,jt2,jt3,jt4,jt5;
	private JLabel jl1,jl2,jl3,jl4,jl5;
	private JPanel jp1,jp2,jp3;
	private JButton jb1,jb2;
	private JRadioButton jrb1,jrb2;
	private ButtonGroup bg;
	private DBconnect db=new DBconnect();
	int i=0;
	
	public studentOut() {
		super();

		jb1=new JButton("�Ǽ�");
		jb2=new JButton("ȡ��");
		jrb1=new JRadioButton("��");
		jrb2=new JRadioButton("��");
		bg=new ButtonGroup();
		bg.add(jrb1);
		bg.add(jrb2);
		
		jp1=new JPanel();
		jp2=new JPanel();
		jp3=new JPanel();
		jt1=new JTextField(10);
		jt2=new JTextField(10);
		jt3=new JTextField(10);
		jt4=new JTextField(10);
		jt5=new JTextField(10);
		jl1=new JLabel("  ѧ ��");
		jl2=new JLabel("  �� �� �� ��");
		jl3=new JLabel("  �� �� ʱ ��");
		jl4=new JLabel("  �� �� ʱ ��");
		jl5=new JLabel("  �� �� �� ��");
		
		Font font = new Font("��������", Font.BOLD|Font.PLAIN, 14);
		jl1.setFont(font);
		jl2.setFont(font);
		jl3.setFont(font);
		jl4.setFont(font);
		jl5.setFont(font);
		
		jp1.setLayout(new GridLayout(6,1));
		jp1.add(jl1);
		jp1.add(jt1);
		jp1.add(jl2);
		jp1.add(jt2);
		jp1.add(jl3);
		jp1.add(jt3);
		jp1.add(jl4);
		jp1.add(jt4);
		jp1.add(jl5);
		jp3.add(jrb1);
		jp3.add(jrb2);
		jp1.add(jp3);
		jp2.setLayout(new FlowLayout());
		jp2.add(jb1);
		jp2.add(jb2);
		setLayout(new GridLayout(2,1));
		add(jp1);
		add(jp2);
		
		addButtonAction();
		
		setTitle("ѧ�����");
		setSize(400,300);
		setVisible(true);
		setLocationRelativeTo(null);
	}
		
	private void addButtonAction() {
		jb1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String str1,str2,str3,str4,str5 = null;
				str1=jt1.getText();
				str2=jt2.getText();
				str3=jt3.getText();
				str4=jt4.getText();
				if (jrb1.isSelected()){
					str5="��";
				}
				else if (jrb2.isSelected()){
					str5="��";
				}
				int num=Integer.parseInt(str1);
				try {
					String sql1="SELECT MAX(Inout_num) FROM inout_info";
					Statement statement=db.dbConn.createStatement();
					ResultSet res=statement.executeQuery(sql1);
					res.next();
					i=res.getInt(1)+1;
					String sql="insert into inout_info values ("+num+","+i+",'"+str3+"','"+str4+"','"+str2+"','"+str5+"')";
					statement.executeUpdate(sql);
				}catch(Exception ei) {
					ei.printStackTrace();
				}
				}});
		jb2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				}});
	}
}
	
class studentQueryAlter extends JDialog implements ActionListener{
	private JTextField jt1,jt2;
	private JLabel jl1;
	private JComboBox cmb;
	private JButton jb1,jb2;
	private JPanel jp1;
	private JTable tb;
	private String arr[]={"ѧ��","����","�Ա�","����","ϵ���","�༶","�绰"};
	private String ar[]={"--��ѡ��--","����","�Ա�","����","ϵ���","�༶","�绰"};
	private String ar1[]={"--��ѡ��--","Name","Sex","Age","Dept_num","Class","Phonenum"};
	private String comm[][]=new String[10][7];
	private DBconnect DB = new DBconnect();
	
	public studentQueryAlter() {
		super();
		cmb=new JComboBox(ar);
		jt1=new JTextField(10);
		jt2=new JTextField(10);
		jl1=new JLabel("ѧ �ţ�");
		jl1.setFont(new Font("��������", Font.BOLD|Font.PLAIN, 14));
		jb1=new JButton("��ѯ");
		jb2=new JButton("�޸�");
		jp1=new JPanel();
		tb=new JTable();
		jp1.add(jl1);
		jp1.add(jt1);
		jp1.add(jb1);
		jp1.add(tb);

		this.setLayout(new FlowLayout());
		this.add(jp1);
		add(cmb);
		add(jt2);
		add(jb2);
		jb1.addActionListener(this);
		jb2.addActionListener(this);
		
		setTitle("ѧ����ѯ/�޸�");
		setSize(300,300);
		setVisible(true);
		setLocationRelativeTo(null);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == jb1) {
			String acct = jt1.getText();
			//System.out.print(cmb.getSelectedIndex());
			try {
				String sql = "select * from stu_info where Stu_num=" + acct;
				Statement statement = DB.dbConn.createStatement();
				ResultSet res = statement.executeQuery(sql);
				while (res.next()) {
					comm[1][0] = arr[0] + ":  " + res.getString(1);
					comm[1][1] = arr[1] + ":  " + res.getString(2);
					comm[1][2] = arr[2] + ":  " + res.getString(3);
					comm[1][3] = arr[3] + ":  " + res.getString(4);
					comm[1][4] = arr[4] + ":  " + res.getString(5);
					comm[1][5] = arr[5] + ":  " + res.getString(6);
					comm[1][6] = arr[6] + ":  " + res.getString(7);
					JOptionPane.showMessageDialog(null, comm);
				}
				res.close();
			} catch (Exception ei) {
				ei.printStackTrace();
			}
		}
		else if (e.getSource()==jb2){
			try {
				String sql1="UPDATE stu_info\n" +
						"SET "+ar1[cmb.getSelectedIndex()]+"="+jt2.getText()+
						"WHERE Stu_num="+jt1.getText();
				Statement statement=DB.dbConn.createStatement();
				statement.executeUpdate(sql1);
				JOptionPane.showMessageDialog(null,"�޸ĳɹ���");
			}catch(Exception ei) {
				ei.printStackTrace();
			}
		}
	}

}

class studentTable extends JDialog {
	private JLabel jl;
	private JTable table;
	private DefaultTableModel model;
	private DBconnect DB = new DBconnect();

	public studentTable() {
		super();
		setLayout(new BorderLayout());
		model=new DefaultTableModel();
		table=new JTable();
		table.setModel(model);
		JScrollPane jsp=new JScrollPane(table);
		jl=new JLabel("ѧ  ��  ��  Ϣ  ��");
		jl.setFont(new Font("���Ĳ���", Font.BOLD|Font.PLAIN, 20));

		this.add(jl,BorderLayout.NORTH);
		this.add(jsp,BorderLayout.CENTER);
			
		this.setTitle("ѧ����Ϣ����");
		setSize(800,500);
		model.setRowCount(0);
		model.setColumnCount(0);
		try {
			String sql="SELECT * FROM stu_info";
			Statement statement=DB.dbConn.createStatement();
			ResultSet res=statement.executeQuery(sql);
			//��ȡ������������������Ϊ��������ı���
			ResultSetMetaData rsmd=res.getMetaData();
			//�������
			int count=rsmd.getColumnCount();
			////���������ӵ�����ģ����Ϊ����
			for(int i=1;i<=count;i++){
				model.addColumn(rsmd.getColumnName(i));
			}
			String[] row=new String[count];
			while(res.next()){
				for(int i=0;i<count;i++)
					row[i]=res.getString(i+1);
				//����һ��
				model.addRow(row);
			}
			res.close();
		}catch(Exception ei) {
			ei.printStackTrace();
		}
		setVisible(true);
		setLocationRelativeTo(null);	
	}
}

class studentReport extends JDialog{
	private JComboBox jc;
	private DBconnect DB = new DBconnect();
	private JTable table;
	private DefaultTableModel model;
	
	public studentReport() {
		String[] str= {"---��ѡ��---","����δ�ϱ�ѧ��","�����ϱ�ѧ��"};
		jc=new JComboBox<String>(str);
		model=new DefaultTableModel();
		table=new JTable();
		table.setModel(model);
		JScrollPane jsp=new JScrollPane(table);
		addAction();
		this.setLayout(new BorderLayout());
		this.add(jc,BorderLayout.NORTH);
		this.add(jsp,BorderLayout.CENTER);
		this.setTitle("ѧ���ϱ�");
		setSize(400,300);
		setVisible(true);
		setLocationRelativeTo(null);	
	}

	private void addAction() {
		 jc.addItemListener(new ItemListener() {
	            @Override
	            public void itemStateChanged(ItemEvent e) {
	            	model.setRowCount(0);
	            	model.setColumnCount(0);
	                if(e.getStateChange() == ItemEvent.SELECTED) {
	                	//�������ݿ��������ֱ�
						String str1=null;
	                    if(jc.getSelectedItem().toString().equals("����δ�ϱ�ѧ��"))
							str1="��";
	                    else
							str1="��";
						try {
							String sql="SELECT * FROM report_info\n" +
									"WHERE Report_TF='"+str1+"'";
							Statement statement=DB.dbConn.createStatement();
							ResultSet res=statement.executeQuery(sql);
							//��ȡ������������������Ϊ��������ı���
							ResultSetMetaData rsmd=res.getMetaData();
							//�������
							int count=rsmd.getColumnCount();
							////���������ӵ�����ģ����Ϊ����
							for(int i=1;i<=count;i++){
								model.addColumn(rsmd.getColumnName(i));
							}
							String[] row=new String[count];
							while(res.next()){
								for(int i=0;i<count;i++)
									row[i]=res.getString(i+1);
								//����һ��
								model.addRow(row);
							}
							res.close();
						}catch(Exception ei) {
							ei.printStackTrace();
						}
	                }
	            }  });
	}
	
}


class classQuery extends JDialog{
	private JTextField jt1,jt2;
	private JLabel jl1,jl2;
	private JButton jb1;
	private JPanel jp1,jp2;
	private DBconnect DB = new DBconnect();
	public classQuery() {
		super();
		jt1=new JTextField(6);
		jt2=new JTextField(6);
		jl1=new JLabel("ϵ    ��");
		jl2=new JLabel("��    ����");
		jl1.setFont(new Font("��������", Font.BOLD|Font.PLAIN, 14));
		jl2.setFont(new Font("��������", Font.BOLD|Font.PLAIN, 14));
		
		jb1=new JButton("�� ѯ");
		jp1=new JPanel();
		jp2=new JPanel();
		
		jp1.setLayout(new GridLayout(2,2));
		jp1.add(jl1);
		jp1.add(jt1);
		jp1.add(jl2);
		jp1.add(jt2);
		jp2.add(jb1);
		this.setLayout(new GridLayout(3,1));
		this.add(jp1);
		this.add(jp2);
		
		addAction();
		
		setTitle("�༶��ѯ");
		setSize(400,300);
		setVisible(true);
		setLocationRelativeTo(null);
	}

	private void addAction() {
		jb1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String dept=jt1.getText();
				String clas=jt2.getText();
				String name[]=new String[10];
				int i=0;
				try {
					String sql="SELECT" +
							"\t* \n" +
							"FROM\n" +
							"\tstu_info,\n" +
							"\tdept_info \n" +
							"WHERE\n" +
							"\tstu_info.Dept_num= dept_info.Dept_num \n" +
							"\tAND dept_info.Dept_name= '"+dept+"'"+
							"AND stu_info.Class='"+clas+"'";
					Statement statement=DB.dbConn.createStatement();
					ResultSet res=statement.executeQuery(sql);
					while(res.next()){
						name[i]=res.getString(1)+"   "+res.getString(2)
						+res.getString(3)+"   "+res.getString(4);
						i++;
					}
					res.close();
				}catch(Exception ei) {
					ei.printStackTrace();
				}
				JOptionPane.showMessageDialog(null,name);
				}});
	}	
	
}
