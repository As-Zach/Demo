package GUIdemo;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class foreignerManagement {
	public static void main(String[] args) {
		new foreignerCheckin();
		//new foreignerTable();
	}
}

class foreignerCheckin extends JDialog implements ActionListener{
	private JTextField jtf1,jtf2,jtf3;
	private JButton jb,jb1;
	private JLabel jl1,jl2,jl3;
	private DBconnect DB = new DBconnect();

	public foreignerCheckin(){
		super();
		setLayout(new GridLayout(4,2));
		setTitle("������Ա�Ǽ�");
		setSize(300,200);
		setLocationRelativeTo(null);
		jb = new JButton("��  ��");
		jb1 = new JButton("ȡ  ��");
		jtf1 = new JTextField(10);
		jtf2 = new JTextField(10);
		jtf3 = new JTextField(10);
		jl1 = new JLabel("��  ��:");
		jl2 = new JLabel("��  ��:");
		jl3 = new JLabel("̽ �� ѧ �� �� ѧ ��:");
		add(jl1);
		add(jtf1);
		add(jl2);
		add(jtf2);
		add(jl3);
		add(jtf3);
		add(jb);
		add(jb1);
		jb.addActionListener(this);
		jb1.addActionListener(this);
		setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == jb){
			try {
				String name = jtf1.getText();
				int phone = Integer.parseInt(jtf2.getText());
				int num = Integer.parseInt(jtf3.getText());
				String sql1="select MAX(Visit_num) from visit_info";
				Statement statement=DB.dbConn.createStatement();
				ResultSet res = statement.executeQuery(sql1);
				res.next();
				int i = res.getInt(1)+1;
				String sql2 = "INSERT visit_info VALUES("+i+",'"+name+"',"+phone+","+num+")";
				statement.executeUpdate(sql2);
				JOptionPane.showMessageDialog(null,"����ɹ���");
			}catch(Exception ei) {
				ei.printStackTrace();
			}
		}
		else {
			dispose();
		}
	}
}

class foreignerTable extends JDialog{
	private JLabel jl;
	private JTable table;
	private DefaultTableModel model;
	private DBconnect DB = new DBconnect();

	public foreignerTable() {
		super();
		setLayout(new BorderLayout());
		model=new DefaultTableModel();
		table=new JTable();
		table.setModel(model);
		JScrollPane jsp=new JScrollPane(table);
		jl=new JLabel("��  ��  ��  Ա  ��  Ϣ  ��");
		jl.setFont(new Font("���Ĳ���", Font.BOLD|Font.PLAIN, 20));

		this.add(jl,BorderLayout.NORTH);
		this.add(jsp,BorderLayout.CENTER);

		this.setTitle("������Ա��Ϣ����");
		setSize(400,500);
		model.setRowCount(0);
		model.setColumnCount(0);
		try {
			String sql="SELECT * FROM visit_info";
			Statement statement=DB.dbConn.createStatement();
			ResultSet res=statement.executeQuery(sql);
			//��ȡ������������������Ϊ��������ı���
			ResultSetMetaData rsmd=res.getMetaData();
			//�������
			int count=rsmd.getColumnCount();
			////���������ӵ�����ģ����Ϊ����
			for(int i=1;i<=count;i++){
				model.addColumn(rsmd.getColumnName(i));
			}
			String[] row=new String[count];
			while(res.next()){
				for(int i=0;i<count;i++)
					row[i]=res.getString(i+1);
				//����һ��
				model.addRow(row);
			}
			res.close();
		}catch(Exception ei) {
			ei.printStackTrace();
		}
		setVisible(true);
		setLocationRelativeTo(null);
	}
	
}