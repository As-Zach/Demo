package GUIdemo;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBconnect {
    Connection dbConn;
    public DBconnect(){
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String dbURL = "jdbc:sqlserver://127.0.0.1:1433;DatabaseName=ssgl";
            dbConn = DriverManager.getConnection(dbURL, "sa", "sa");
        }catch(Exception ei) {
            ei.printStackTrace();
            System.out.println("连接数据库失败！");
        }
    }
}
