package GUIdemo;

import javax.swing.JDialog;

public class workerManagement {
	public static void main(String[] args) {
		//new studentOut();
		//new studentQuery();
		new studentTable();
	}
}

class workerforeignerCheckin extends JDialog{
	

}

class workerforeignerTable extends JDialog{
	
	
}
