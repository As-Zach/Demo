package GUIdemo;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class dormitoryDisp extends JFrame{
	Container container;
	JTabbedPane tabbedPane;   //��ǩ���
	JPanel[] Panels;
	JButton jb01,jb02,jb03,jb11,jb12,jb13,jb14,jb15,jb21,jb22,
	jb31,jb32,jb33,jb34,jb35;
	
	public dormitoryDisp() {
		super();	
	
		//��ǩ����ʼ��
		InitTabbedPane();
		InitPanels();
		addButtonAction();
		
		setTitle("�������Ա����");
		setSize(600,500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}
	
	private void InitTabbedPane() {
		//����ʼ��
		Panels=new JPanel[4];
		Panels[0] = new JPanel();
	    Panels[1] = new JPanel();
	    Panels[2] = new JPanel();
	    Panels[3] = new JPanel();
	    
		//�ڶ���������ǩ���
		tabbedPane =new JTabbedPane(JTabbedPane.TOP);
		//��ʼ�������������Ӳ���
		container=this.getContentPane();
		container.add(tabbedPane);

		
		//�������
		tabbedPane.add("ϵͳ����",Panels[0]);
		tabbedPane.add("�������",Panels[1]);
		tabbedPane.add("������Ա",Panels[2]);
		tabbedPane.add("ѧ������",Panels[3]);
	     
	    Font font = new Font("��������", Font.BOLD|Font.PLAIN, 15);
	    tabbedPane.setFont(font);
	    tabbedPane.setBackground(Color.YELLOW);
	}
	
	private void InitPanels() {
		//ϵͳ�������
		jb01=new JButton("�����û�");
		jb02=new JButton("ɾ���û�");
		jb03=new JButton("�û���Ϣ���ܱ�");
		Panels[0].setLayout(new GridLayout(3,1));
		Panels[0].add(jb01);
		Panels[0].add(jb02);
		Panels[0].add(jb03);
		
		//����������
		jb11=new JButton("��ס��Ϣ��ѯ");
		jb12=new JButton("ѧ������");
		jb13=new JButton("����ά�޹���");
		jb14=new JButton("����ɷѹ���");
		jb15=new JButton("������Ϣ���ܱ�");
		Panels[1].setLayout(new GridLayout(5,1));
		Panels[1].add(jb11);
		Panels[1].add(jb12);
		Panels[1].add(jb13);
		Panels[1].add(jb14);
		Panels[1].add(jb15);
		
		//������Ա�������
		jb21=new JButton("������Ա�Ǽ�");
		jb22=new JButton("������Ա��Ϣ���ܱ�");
		Panels[2].setLayout(new GridLayout(2,1));
		Panels[2].add(jb21);
		Panels[2].add(jb22);
	
		//ѧ���������
		jb31=new JButton("ѧ����Ϣ��ѯ/�޸�");
		jb32=new JButton("�༶��ѯ");
		jb33=new JButton("ѧ�����");
		jb34=new JButton("ѧ���ϱ���ѯ");
		jb35=new JButton("ѧ����Ϣ���ܱ�");
		Panels[3].setLayout(new GridLayout(5,1));
		Panels[3].add(jb31);
		Panels[3].add(jb32);
		Panels[3].add(jb33);
		Panels[3].add(jb34);
		Panels[3].add(jb35);
		
	}
	
	
	private void addButtonAction() {
		jb01.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UserCheckin();
				}});
		jb02.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UserDelete();
				}});
		jb03.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new UserTable();
				}});
		jb11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new dormSearch();
				}});
		jb12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new dormChange();
				}});
		jb13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new dormRepair();
				}});
		jb14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new dormMoney();
				}});
		jb15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new dormTable();
				}});
		jb21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new foreignerCheckin();
				}});
		jb22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new foreignerTable();
				}});
		jb31.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new studentQueryAlter();
				}});
		jb32.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new classQuery();
				}});
		jb33.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new studentOut();
				}});
		jb34.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new studentReport();
				}});
		jb35.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new studentTable();
				}});

	}
	
	public static void main(String[] args) {
		new dormitoryDisp();
	}
}
